# Brodcast-Receiver-Internet-Connectivity
Komponen ini berfungsi untuk memantau dan menanggapi perubahan status koneksi internet pada perangkat. Ketika jaringan berganti, misalnya ke Wi-Fi atau data seluler, sistem akan mengirimkan notifikasi yang dapat diterima oleh Broadcast Receiver.

# Tool Used
- Andriod Studio
- Java
